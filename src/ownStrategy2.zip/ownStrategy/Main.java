package ownStrategy;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;
import yahoofinance.Stock;
import yahoofinance.YahooFinance;

import javax.swing.text.html.Option;

abstract class OptionStrategy {
    private String name;
    private boolean ls;
    SpreadStrategy spread;
    private double ogspread;
    public double getOgspread() {
        return ogspread;
    }
    public void  setOgspread(double ogspread) {
        this.ogspread = ogspread;
    }
    public abstract boolean getCP();
    private OptionType type;
    public OptionType getType() {
        return type;
    }
    public void setType(OptionType type) {
        this.type = type;
    }
    private double price;
//glowna metoda
    public List<Double> setThePrices(double price, List<Double> spreads, OptionStrategy o) {
        return spread.AllPrices(price, spreads, o);
    }
    public List <OptionLeg> setOptionLegs(List<Double> prices, OptionType type) {
        return null;
    }
    public abstract int getSpreadNumber();
    public OptionStrategy(String name, boolean ls) {
        this.name = name;
        this.ls = ls;
    }

    public String getName() {
        return name;
    }

    public double  getPrice() {
        return price;
    }

    public boolean LongOrShort() {
        return ls;
    }

    public abstract void setName();

    public void setLs(boolean ls) {
        this.ls = ls;
    }

/*    public Double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public List<Double> getSpreads() {
        return spreads;
    }

    public void setSpreads(List<Double> spreads) {
        this.spreads = spreads;
    }

    public void addToSpreads(Double spread){
        this.spreads.add(spread);
    }
*/
    private double price1;
    private double price2;
    private double price3;
    private double price4;

    public double getPrice1() {
        return price1;
    }

    public void setPrice1(double price1) {
        this.price1 = price1;
    }

    public double getPrice2() {
        return price2;
    }

    public void setPrice2(double price2) {
        this.price2 = price2;
    }

    public double getPrice3() {
        return price3;
    }

    public void setPrice3(double price3) {
        this.price3 = price3;
    }

    public double getPrice4() {
        return price4;
    }

    public void setPrice4(double price4) {
        this.price4 = price4;
    }

    private static List<String> strategyTypes = new ArrayList<>();

    protected void addStrategyType(String type) {
        strategyTypes.add(type);
    }

    public static List<String> getStrategyTypes() {
        return strategyTypes;
    }

    static{
        strategyTypes.add("Butterfly Spread");
        strategyTypes.add("Vertical Spread");
        strategyTypes.add("Iron Condor");
        strategyTypes.add("Ratio Spread");
        strategyTypes.add("Iron Butterfly");
        strategyTypes.add("Straddle");
    }

    private static List<String> companyTypes = new ArrayList<>();

    protected void addCompanyType(String type) {
        companyTypes.add(type);
    }

    public static List<String> getCompanyTypes() {
        return companyTypes;
    }

    static{
        companyTypes.add("AAPL");
        companyTypes.add("TSLA");
        companyTypes.add("MSFT");
        companyTypes.add("GOOGL");
        companyTypes.add("AMZN");
        companyTypes.add("NVDA");
        companyTypes.add("CDR.WA");
        companyTypes.add("PKO.WA");
        companyTypes.add("KGH.WA");
        companyTypes.add("BTC-USD");
        companyTypes.add("ETH-USD");
    }
}

class ButterflySpread extends OptionStrategy {
    private String name;
    private OptionType type;
    private final int spreadNumber = 1;

    public ButterflySpread(String name, boolean LS) {
        super(name, LS);
    }
    @Override
    public boolean getCP() {
        return true;
    }

    @Override
    public List <Double> setThePrices(double price,  List<Double> spreads, OptionStrategy o) {
        List <Double> butterfly = new ArrayList<>();
        OneSpreadStrategy alfa = new OneSpreadStrategy();
        butterfly = alfa.AllPrices(price, spreads, o);
        butterfly.add(price);
        butterfly.add(price);
        Collections.swap(butterfly, 1, 3);
        return butterfly;
    }
    @Override
    public List <OptionLeg> setOptionLegs(List<Double> prices, OptionType type){
        List <OptionLeg> legs = new ArrayList<>();
        if(this.LongOrShort()){
            legs.add(new OptionLeg(prices.get(0), type, Belfort.BUY));
            legs.add(new OptionLeg(super.getPrice(), type, Belfort.SELL));
            legs.add(new OptionLeg(super.getPrice(), type, Belfort.SELL));
            legs.add(new OptionLeg(prices.get(1), type, Belfort.BUY));
        }
        else{
            legs.add(new OptionLeg(prices.get(0), type, Belfort.SELL));
            legs.add(new OptionLeg(super.getPrice(), type, Belfort.BUY));
            legs.add(new OptionLeg(super.getPrice(), type, Belfort.BUY));
            legs.add(new OptionLeg(prices.get(1), type, Belfort.SELL));
        }
        return legs;
    }

    @Override
    public void setName() {
        if(this.LongOrShort()){
            this.name = "Long Butterfly Spread";
        }
        else{
            this.name = "Short Butterfly Spread";
        }
    }

    public int getSpreadNumber(){
        return this.spreadNumber;
    }
}

class VerticalSpread extends OptionStrategy {
    private String name;
    private final int spreadNumber = 1;

    @Override
    public boolean getCP() {
        return true;
    }

    public VerticalSpread(String name, boolean LS) {
        super(name, LS);
    }

    @Override
    public List <Double> setThePrices(double price,  List<Double> spreads, OptionStrategy o) {
        List <Double> vertical = new ArrayList<>();
        OneSpreadStrategy alfa = new OneSpreadStrategy();
        vertical = alfa.AllPrices(price, spreads, o);
        return vertical;
    }
    @Override
    public List <OptionLeg> setOptionLegs(List<Double> prices, OptionType type){
        List <OptionLeg> legs = new ArrayList<>();
        if(this.LongOrShort()){
            legs.add(new OptionLeg(prices.get(0), type, Belfort.BUY));
            legs.add(new OptionLeg(prices.get(1), type, Belfort.SELL));
        }
        else{
            legs.add(new OptionLeg(prices.get(0), type, Belfort.SELL));
            legs.add(new OptionLeg(prices.get(1), type, Belfort.BUY));
        }
        return legs;
    }

    @Override
    public void setName() {
        if(this.LongOrShort()){
            this.name = "Long Vertical Spread";
        }
        else{
            this.name = "Short Vertical Spread";
        }
    }

    public int getSpreadNumber(){
        return this.spreadNumber;
    }
}

class IronCondor extends OptionStrategy {
    private String name;
    private final int spreadNumber = 2;

    public IronCondor(String name, boolean LS) {
        super(name, LS);
    }
    @Override
    public boolean getCP() {
        return true;
    }

    @Override
    public List <Double> setThePrices(double price,  List<Double> spreads, OptionStrategy o) {
        List <Double> Condor = new ArrayList<>();
        TwoSpreadStrategy beta = new TwoSpreadStrategy();
        Condor = beta.AllPrices(price, spreads, o);
        return Condor;
    }
    @Override
    public List <OptionLeg> setOptionLegs(List<Double> prices, OptionType type){
        if(this.LongOrShort()){
            List <OptionLeg> legs = new ArrayList<>();
            legs.add(new OptionLeg(prices.get(0), OptionType.PUT, Belfort.BUY));
            legs.add(new OptionLeg(prices.get(1), OptionType.PUT, Belfort.SELL));
            legs.add(new OptionLeg(prices.get(2), OptionType.CALL, Belfort.SELL));
            legs.add(new OptionLeg(prices.get(3), OptionType.CALL, Belfort.BUY));
            return legs;
        }
        else{
            List <OptionLeg> legs = new ArrayList<>();
            legs.add(new OptionLeg(prices.get(0), OptionType.PUT, Belfort.SELL));
            legs.add(new OptionLeg(prices.get(1), OptionType.PUT, Belfort.BUY));
            legs.add(new OptionLeg(prices.get(2), OptionType.CALL, Belfort.BUY));
            legs.add(new OptionLeg(prices.get(3), OptionType.CALL, Belfort.SELL));
            return legs;
        }
    }

    @Override
    public void setName() {
        if(this.LongOrShort()){
            this.name = "Long Iron Condor";
        }
        else{
            this.name = "Iron Condor";
        }
    }

    public int getSpreadNumber(){
        return this.spreadNumber;
    }
}

class RatioSpread extends OptionStrategy {
    private String name;
    private final int spreadNumber = 1;
    public RatioSpread(String name, boolean LS) {
        super(name, LS);
    }
    @Override
    public boolean getCP() {
        return true;
    }
    @Override
    public OptionType getType(){
        return super.getType();
    }
    List<Double> prices = new ArrayList<>();
    public List <Double> setThePrices(double price,  List<Double> spreads, OptionStrategy o){
        List<Double> prices = new ArrayList<>();
        prices.add(price);
        return prices;
    }
    @Override
    public List<OptionLeg> setOptionLegs(List<Double> prices, OptionType type) {
        double spread = super.getOgspread();
        List<OptionLeg> legs = new ArrayList<>();
        if (this.LongOrShort()) {
            if (getType().equals(OptionType.PUT)) {
                legs.add(new OptionLeg(prices.get(0) - spread, OptionType.PUT, Belfort.SELL));
                legs.add(new OptionLeg(prices.get(0) - spread, OptionType.PUT, Belfort.SELL));
                legs.add(new OptionLeg(prices.get(0), OptionType.PUT, Belfort.BUY));
            } else {
                legs.add(new OptionLeg(prices.get(0), OptionType.CALL, Belfort.BUY));
                legs.add(new OptionLeg(prices.get(0) + spread, OptionType.CALL, Belfort.SELL));
                legs.add(new OptionLeg(prices.get(0) + spread, OptionType.CALL, Belfort.SELL));
            }
            return legs;
        } else {
            if (getType().equals(OptionType.PUT)) {
                legs.add(new OptionLeg(prices.get(0) - spread, OptionType.PUT, Belfort.BUY));
                legs.add(new OptionLeg(prices.get(0) - spread, OptionType.PUT, Belfort.BUY));
                legs.add(new OptionLeg(prices.get(0), OptionType.PUT, Belfort.SELL));
            } else {
                legs.add(new OptionLeg(prices.get(0), OptionType.CALL, Belfort.SELL));
                legs.add(new OptionLeg(prices.get(0) + spread, OptionType.CALL, Belfort.BUY));
                legs.add(new OptionLeg(prices.get(0) + spread, OptionType.CALL, Belfort.BUY));
            }
        }
        return legs;
    }

    @Override
    public void setName() {
        if(this.LongOrShort()){
            this.name = "Long Ratio Spread";
        }
        else{
            this.name = "Short Ratio Spread";
        }
    }

    public int getSpreadNumber(){
        return this.spreadNumber;
    }
}
/*
class IronButterfly extends OptionStrategy {
    private String name;

    public IronButterfly(String name, boolean LS, OptionType type) {
        super(name, LS, type);
    }

    public void setThePrices(double price,  List<Double> spreads, OptionStrategy o) {
        SpreadStrategy alfa = new OneSpreadStrategy();
        alfa.setAllPrices(price, spreads, this);
    }

    @Override
    public void setName() {
        if(this.LongOrShort()){
            this.name = "Long Iron Butterfly";
        }
        else{
            this.name = "Iron Butterfly";
        }
    }

}
class Strangle extends OptionStrategy {
    private String name;
    public Strangle(String name, boolean LS, OptionType type) {
        super(name, LS, type);
    }

    public void setThePrices(double price,  List<Double> spreads, OptionStrategy o) {
        SpreadStrategy alfa = new OneSpreadStrategy();
        alfa.setAllPrices(price, spreads, this);
    }

    @Override
    public void setName() {
        if(this.LongOrShort()){
            this.name = "Long Strangle";
        }
        else{
            this.name = "Short Strangle";
        }
    }

}

/*wezmę se dowolną niespreadową opcję, żeby nie było, ze wszystkie strategie są spreadowe
class Straddle extends OptionStrategy {
    private String name;

    public Straddle(String name, boolean LS, OptionType type) {
        super(name, LS, type);
    }

    @Override
    public void setName() {
        if(this.LongOrShort()){
            this.name = "Long Straddle";
        }
        else{
            this.name = "Short Straddle";
        }
    }
}
*/
interface SpreadStrategy{
    List<Double> AllPrices(double price, List<Double> spreadValues, OptionStrategy strategy);
}

class OneSpreadStrategy implements SpreadStrategy{
    public List<Double> AllPrices(double price, List<Double> spreadValues, OptionStrategy o) {
        List <Double> prices = new ArrayList<>();
        double o1 = price + spreadValues.get(0);
        double o2 = price - spreadValues.get(0);
        prices.add(o2);
        prices.add(o1);
        return prices;
    }
}

class TwoSpreadStrategy implements SpreadStrategy{
    public List<Double> AllPrices(double price, List<Double> spreadValues, OptionStrategy o){
        List<Double> prices = new ArrayList<>();
        Double d1 = price + spreadValues.get(0);
        Double d2 = price - spreadValues.get(0);
        Double d3 = price + spreadValues.get(0) + spreadValues.get(1);
        Double d4 = price - spreadValues.get(0) - spreadValues.get(1);
        prices.add(d4);
        prices.add(d2);
        prices.add(d1);
        prices.add(d3);
        return prices;
    }
}

public class Main {
    public static void main(String[] args) {
        boolean inv = true;
        Scanner sc = new Scanner(System.in);
        String Strategy = null;
        boolean llong = false;
        OptionStrategy os = null;
        while (inv) {
            System.out.println("Choose your strategy:  \nButterfly Spread \nVertical Spread \nRatio Spread \nIron Condor");//Iron Butterfly \nStraddle");
            String s = sc.nextLine();
            if (OptionStrategy.getStrategyTypes().contains(s)) {
                inv = false;
                Strategy = s;
            }
        }
        inv = true;
        while (inv) {
            System.out.println("Long or short?");
            String longOrShort = sc.nextLine();
            if (longOrShort.equals("Long") || longOrShort.equals("long")) {
                llong = true;
                inv = false;
            } else if (longOrShort.equals("Short") ||  longOrShort.equals("short")) {
                inv = false;
            }
        }
        inv = true;
        //output
//        String inputName = "Iron Condor";
        try {
            String className = "ownStrategy." + Strategy.replace(" ", "");
            Class<?> clazz = Class.forName(className);
            java.lang.reflect.Constructor<?> constructor = clazz.getConstructor(String.class, boolean.class);
            os = (OptionStrategy) constructor.newInstance(Strategy, llong);
        } catch (ClassNotFoundException e) {
            System.out.println("Choose the right strategy!");
        } catch (Exception e) {
            System.out.println("Error found: " + e.getMessage());
            e.printStackTrace();
        }
        if(os.LongOrShort())
            System.out.println("Your strategy: Long " + os.getName());
        else
            System.out.println("Your strategy: Short " + os.getName());
        try{
            while(inv) {
                System.out.println("Instances of American companies: AAPL, TSLA, MSFT, GOOGL, AMZN, NVDA"); // USA
                System.out.println("Instances of Polish companies: CDR.WA, PKO.WA, KGH.WA");                    // Polska (wymagany sufiks .WA)
                System.out.println("Instances of cryptocurrencies: BTC-USD, ETH-USD");                             // Krypto
                System.out.println("In which company do you want to invest: ");
                String company = sc.nextLine();
                if (YahooFinance.get(company) != null) {
                    Stock stock = YahooFinance.get(company);
                    System.out.println("You invested in: " + stock.getName());
                    BigDecimal price = stock.getQuote().getPrice();
                    System.out.println("The price of " + stock.getName() + " is: " + price);
                    inv = false;
                }
            }
        }
        catch(Exception e){
            e.printStackTrace();
        }
        double price = 0;
        double spread = 0;
        List<Double> spreadValues = new ArrayList<>();
        try {
            System.out.println("Again");
            System.out.println("Instances of American companies: AAPL, TSLA, MSFT, GOOGL, AMZN, NVDA"); // USA
            System.out.println("Instances of Polish companies: CDR.WA, PKO.WA, KGH.WA");                    // Polska (wymagany sufiks .WA)
            System.out.println("Instances of cryptocurrencies: BTC-USD, ETH-USD");                             // Krypto
            System.out.println("In which company do you want to invest: ");
            while(inv){
                String company = sc.nextLine();
                if (!OptionStrategy.getCompanyTypes().contains(company)) {
                    System.out.println("Choose the right company!");
                }
                else{
                    System.out.println("Enter the current price: ");
                    price = sc.nextDouble();
                    for(int i = 1; i <= os.getSpreadNumber(); i++){
                        System.out.println("Enter the spread no. " + i);
                        double spreadValue = sc.nextDouble();
                        if(price > spreadValue){
                            if(i == 1){
                                os.setOgspread(spreadValue);
                            }
                            spreadValues.add(spreadValue);
                        }
                        else{
                            System.out.println("Enter the right value!");
                            i--;
                        }
                        sc.nextLine();
                    }
                    inv = false;
                }
            }
        }
        catch(Exception e){
            e.printStackTrace();
        }
        inv = true;
        if(os.getCP())
            {
                while(inv){
                    System.out.println("Final question- you want to play PUT or CALL?");
                    String s = sc.nextLine();
                    if(s.equals("PUT")){
                        os.setType(OptionType.PUT);
                        inv = false;
                    }
                    else if(s.equals("CALL")){
                        os.setType(OptionType.CALL);
                        inv = false;
                    }
                    else
                        System.out.println("I already know these tricks. Enter the right word!");
                }
            }
        for(OptionLeg ol: os.setOptionLegs(os.setThePrices(price, spreadValues, os), os.getType())){
            System.out.println(ol);
        }

//zrob setOptionlegs na setprices- bedzie smigac
    }
// dalsza logika
}
//wczytac cenę i spready
//utworzyc pola definiujace call/put na danych miejscach cenowych
//output
//wchodzimy w kolejny wymiar- strategie muszą być też symetryczne
enum OptionType {
    CALL, PUT
}
enum Belfort {
    BUY, SELL;
}
// 2. Co robimy z tą nogą? Kupujemy (Long) czy wystawiamy (Short)?


// 3. Klasa reprezentująca jedną nogę strategii
class OptionLeg {
    private double strikePrice;
    private OptionType type;
    private Belfort belfort;

    public OptionLeg(double strikePrice, OptionType type,  Belfort belfort) {
        this.strikePrice = strikePrice;
        this.type = type;
        this.belfort = belfort;
    }

    // Gettery (Settery nie są konieczne, jeśli noga jest stała po utworzeniu)
    public double getStrikePrice() { return strikePrice; }
    public OptionType getType() { return type; }

    public Belfort getBelfort() {
        return belfort;
    }

    @Override
    public String toString() {
        return belfort + " " + type + " @" + strikePrice;
    }
}
